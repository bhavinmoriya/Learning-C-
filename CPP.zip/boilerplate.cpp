#include <iostream>
#include <string>
using namespace std;
int main()
{ 
    return 0;
}
