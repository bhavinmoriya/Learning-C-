#include <iostream>
#include <string>
using namespace std;

int main(){
    string color;
    cout << "What is your fav color: \n";
    cin >> color;
    cout << color << " is my fav color too!\n";
    return 0;
}