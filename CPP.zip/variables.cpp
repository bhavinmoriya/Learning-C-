#include <iostream>
#include <string>
using namespace std;
int main()
{
    // integers
    int x = 1;
    int y = 2;
    int sum = x + y;
    cout << "The sum of " << x << " and " << y << " is: " << sum << endl;
    // float
    double a = 1.3;
    double b = 2.4;
    double product = a * b;
    cout << "The product of " << a << " and " << b << " is: " << product << endl;
    // character
    char c = 'a';
    char d = '2';
    cout << c << endl;

    // boolean (true or false)
    bool math = true;
    bool chemistry = false;

    // string
    string boy = "John";
    string girl = "Hanna";
    cout << "Hallo " << boy << ". How are you?\n";

    return 0;
}
